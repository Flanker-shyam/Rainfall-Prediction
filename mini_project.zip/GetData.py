import streamlit as st
import joblib
import numpy as np

def calculate_expected_rainfall(data):
    # Replace this with your actual formula for calculating expected rainfall
    # This is just a placeholder formula
    model = joblib.load('model.pkl')
    print("Type data: ", type(data))
    data_array = np.array(list(data.values())).T

    print("nrwe type: ", type(data_array))

    data_array = data_array.reshape(1,-1)
    print("new Ddta: ", data_array)

    expected_rainfall = model.predict(data_array)
    # expected_rainfall = data['HumidityAvgPercent'] * 0.1 + data['WindAvgMPH'] * 0.05
    return expected_rainfall
    # return 0.9

def main():
    st.title("Expected Rainfall Calculator")

    # Create input widgets for each weather variable
    dew_point_high = st.slider("Dew Point High (F)", min_value=0, max_value=100)
    dew_point_avg = st.slider("Dew Point Avg (F)", min_value=0, max_value=100)
    dew_point_low = st.slider("Dew Point Low (F)", min_value=0, max_value=100)
    humidity_high = st.slider("Humidity High (%)", min_value=0, max_value=100)
    humidity_avg = st.slider("Humidity Avg (%)", min_value=0, max_value=100)
    humidity_low = st.slider("Humidity Low (%)", min_value=0, max_value=100)
    pressure_high = st.slider("Sea Level Pressure High (inches)", min_value=28, max_value=32)
    pressure_avg = st.slider("Sea Level Pressure Avg (inches)", min_value=28, max_value=32)
    pressure_low = st.slider("Sea Level Pressure Low (inches)", min_value=28, max_value=32)
    visibility_high = st.slider("Visibility High (miles)", min_value=0, max_value=10)
    visibility_avg = st.slider("Visibility Avg (miles)", min_value=0, max_value=10)
    visibility_low = st.slider("Visibility Low (miles)", min_value=0, max_value=10)
    wind_high = st.slider("Wind High (MPH)", min_value=0, max_value=50)
    wind_avg = st.slider("Wind Avg (MPH)", min_value=0, max_value=50)
    wind_gust = st.slider("Wind Gust (MPH)", min_value=0, max_value=50)

    # Create a dictionary to hold the input data
    input_data = {
        'DewPointHighF': dew_point_high,
        'DewPointAvgF': dew_point_avg,
        'DewPointLowF': dew_point_low,
        'HumidityHighPercent': humidity_high,
        'HumidityAvgPercent': humidity_avg,
        'HumidityLowPercent': humidity_low,
        'SeaLevelPressureHighInches': pressure_high,
        'SeaLevelPressureAvgInches': pressure_avg,
        'SeaLevelPressureLowInches': pressure_low,
        'VisibilityHighMiles': visibility_high,
        'VisibilityAvgMiles': visibility_avg,
        'VisibilityLowMiles': visibility_low,
        'WindHighMPH': wind_high,
        'WindAvgMPH': wind_avg,
        'WindGustMPH': wind_gust
    }

    # Calculate expected rainfall based on the input data
    expected_rainfall = calculate_expected_rainfall(input_data)

    # Display the expected rainfall
    st.subheader("Expected Rainfall:")
    st.write(f"The expected rainfall for the month is: {expected_rainfall} inches")

if __name__ == "__main__":
    main()
